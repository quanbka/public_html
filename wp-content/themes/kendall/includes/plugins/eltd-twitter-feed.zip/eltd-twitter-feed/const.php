<?php

define('ELATED_TWITTER_FEED_ABS_PATH', dirname(__FILE__));
define('ELATED_TWITTER_FEED_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('ELATED_TWITTER_FEED_CPT_PATH', ELATED_TWITTER_FEED_ABS_PATH.'/post-types');